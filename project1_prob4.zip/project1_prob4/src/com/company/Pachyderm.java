package com.company;

public class Pachyderm extends Animal{
    Pachyderm(String pachyName){
        super(pachyName);
    }
}
