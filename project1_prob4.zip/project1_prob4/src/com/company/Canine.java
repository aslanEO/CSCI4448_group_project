package com.company;

public class Canine extends Animal{
    Canine(String canineName){
        super(canineName);
    }
}
